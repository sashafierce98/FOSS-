Javascript Snake
================

Open source javascript version of the snake game, created using the Phaser Engine.

LICENSE
==================

LICENSE
Provided under the [MIT](http://opensource.org/licenses/MIT) license.
